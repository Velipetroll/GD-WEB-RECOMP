Geometry Dash Web Native Port - 1.0.2 (Windows 32-bit)
===================================================

Controls:
- Space / Up Arrow / Left Mouse Button: Jump / Fly
- Escape: Pause menu / Back

Features:
- Direct3D 8 (Intel GMA FastPath), Direct3D 9, OpenGL 1.1
- 240Hz physics simulation, zero external runtime DLL dependencies
- In-game settings popup: FPS Limiter, Renderer selection, Audio controls, Show FPS toggle
- Compatible with Windows XP, Vista, 7, 8, 10, 11 (32-bit & 64-bit)
