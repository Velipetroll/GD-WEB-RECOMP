Geometry Dash Web Native Port - 1.0.3 (Linux x86_64)
===================================================

Run:
  ./GeometryDash

Controls:
- Space / Up Arrow / Left Mouse Button: Jump / Fly
- Escape: Pause menu / Back

Requirements:
- SDL2 (libsdl2-2.0), OpenGL (libGL), zlib
