Geometry Dash Web Native Port - v1.0.3 (Windows 64-bit)
===================================================

Controls:
- Space / Up Arrow / Left Mouse Button: Jump / Fly
- Escape: Pause menu / Back

Features:
- Direct3D 9, OpenGL 1.1
- 240Hz physics simulation, zero external runtime DLL dependencies
- In-game settings popup: FPS Limiter, Renderer selection, Audio controls, Show FPS toggle
- Compatible with Windows 7, 8, 10, 11 (64-bit)
